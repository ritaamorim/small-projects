﻿using System;



    class Program
    {

        public static int mdc(int n, int x)
        {
            int divisor, dividendo, resto;

            if (n == 0 || x == 0)
                System.Console.WriteLine("Não pode introduzir o valor 0");

            if (n > x)
            {
                dividendo = n;
                divisor = x;
            }
            else
            {
                dividendo = n;
                divisor = x;
            }


            while (dividendo % divisor != 0)
            {
                resto = dividendo % divisor;
                dividendo = divisor;
                divisor = resto;
            }

            return dividendo;
 

        }

        static void Main()
        {
            Tuple<int, int>[] tuples = new Tuple<int, int>[3];

            int n1, n2, n3, n4, n5, n6;

            int tupleFirst, tupleSecond, result, iteration;

            string printString;

            // Ler números da consola

            System.Console.WriteLine("Introduza 3 tuplos de números");
            System.Console.WriteLine("Primeiro número do primeiro tuplo");

            n1 = Convert.ToInt32(System.Console.ReadLine());

            System.Console.WriteLine("Segundo número do primeiro tuplo");

            n2 = Convert.ToInt32(System.Console.ReadLine());

            tuples[0] = new Tuple<int,int>(n1, n2);

            System.Console.WriteLine("Primeiro número do segundo tuplo");

            n3 = Convert.ToInt32(System.Console.ReadLine());

            System.Console.WriteLine("Segundo número do segundo tuplo");

            n4 = Convert.ToInt32(System.Console.ReadLine());

            tuples[1] = new Tuple<int, int>(n3, n4);

            System.Console.WriteLine("Primeiro número do terceiro tuplo");

            n5 = Convert.ToInt32(System.Console.ReadLine());

            System.Console.WriteLine("Segundo número do terceiro tuplo");

            n6 = Convert.ToInt32(System.Console.ReadLine());

            tuples[2] = new Tuple<int, int>(n5, n6);


        for (int i=0; i<3; i++)
        {
            tupleFirst = tuples[i].Item1;

            tupleSecond = tuples[i].Item2;

            System.Console.WriteLine(tuples[i]);

            iteration = i + 1;

            result = mdc(tupleFirst, tupleSecond);

            printString = "Resultado do cálculo do mdc no tuplo número " + iteration.ToString() + ": " + result.ToString();

            System.Console.WriteLine(printString);
        }


    }


    }
